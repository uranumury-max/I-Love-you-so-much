package com.ury.alameenaprivate

import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.random.Random

private val Context.store by preferencesDataStore("our_world")
private object Keys {
    val first = stringPreferencesKey("first")
    val second = stringPreferencesKey("second")
    val date = stringPreferencesKey("date")
    val memories = stringSetPreferencesKey("memories")
    val answers = stringSetPreferencesKey("answers")
    val flowers = intPreferencesKey("flowers")
    val capsule = stringPreferencesKey("capsule")
    val invite = stringPreferencesKey("invite")
    val haptics = booleanPreferencesKey("haptics")
}
private val bg = Color(0xFF090D1A)
private val panel = Color(0xFF1B2038)
private val pink = Color(0xFFFF91B8)
private val lilac = Color(0xFFB9A7FF)

class MainActivity : ComponentActivity() {
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON.takeIf { false } ?: 0)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        setContent { OurWorld() }
    }
}

@Composable
private fun OurWorld() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs by context.store.data.collectAsState(initial = null)
    var page by remember { mutableStateOf("home") }
    var first by remember { mutableStateOf("") }
    var second by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var memories by remember { mutableStateOf(listOf<String>()) }
    var flowers by remember { mutableIntStateOf(1) }
    var capsule by remember { mutableStateOf("") }
    var invite by remember { mutableStateOf("") }
    var haptics by remember { mutableStateOf(true) }
    var ready by remember { mutableStateOf(false) }

    LaunchedEffect(prefs) {
        prefs?.let {
            first = it[Keys.first] ?: ""
            second = it[Keys.second] ?: ""
            date = it[Keys.date] ?: LocalDate.now().toString()
            memories = (it[Keys.memories] ?: emptySet()).toList().sorted()
            flowers = it[Keys.flowers] ?: 1
            capsule = it[Keys.capsule] ?: ""
            invite = it[Keys.invite] ?: ""
            haptics = it[Keys.haptics] ?: true
            ready = true
        }
    }
    fun save(block: MutablePreferences.() -> Unit) { scope.launch { context.store.edit(block) } }
    fun buzz() {
        if (haptics) {
            val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (android.os.Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(28, 55))
            else @Suppress("DEPRECATION") v.vibrate(28)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = pink, background = bg, surface = panel)) {
        if (!ready) { Box(Modifier.fillMaxSize().background(bg), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = pink) }; return@MaterialTheme }
        if (first.isBlank() || second.isBlank()) {
            SetupScreen(first, second, date, { first = it }, { second = it }, { date = it }) {
                save { this[Keys.first] = first; this[Keys.second] = second; this[Keys.date] = date }
            }
            return@MaterialTheme
        }
        BackHandler(page != "home") { page = "home" }
        AnimatedContent(page, label = "pages") { p ->
            when (p) {
                "home" -> Home(first, second) { page = it }
                "stars" -> Stars(first, second, ::buzz)
                "garden" -> Garden(flowers) { flowers++; save { this[Keys.flowers] = flowers }; buzz() }
                "memories" -> Memories(memories) { value ->
                    memories = (memories + value).distinct()
                    save { this[Keys.memories] = memories.toSet() }
                }
                "questions" -> Questions()
                "counter" -> Counter(date)
                "capsule" -> Capsule(capsule) { capsule = it; save { this[Keys.capsule] = it } }
                "pair" -> Pairing(invite) { invite = it; save { this[Keys.invite] = it } }
                "settings" -> Settings(first, second, date, haptics,
                    { first = it }, { second = it }, { date = it }, { haptics = it },
                    { save { this[Keys.first] = first; this[Keys.second] = second; this[Keys.date] = date; this[Keys.haptics] = haptics } })
                else -> Home(first, second) { page = it }
            }
        }
    }
}

@Composable
private fun SetupScreen(a:String,b:String,d:String, onA:(String)->Unit,onB:(String)->Unit,onD:(String)->Unit,save:()->Unit) {
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF211833),bg))).padding(24.dp),
        horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
        Text("✨ عالمنا الخاص", fontSize=30.sp, fontWeight=FontWeight.Bold, color=Color.White)
        Text("لنبدأ ببناء عالمنا", color=pink, modifier=Modifier.padding(12.dp))
        Field(a,onA,"اسمك")
        Field(b,onB,"اسم الشخص الآخر")
        Field(d,onD,"تاريخ بداية علاقتكما (YYYY-MM-DD)")
        Button(onClick=save, enabled=a.isNotBlank()&&b.isNotBlank(), modifier=Modifier.fillMaxWidth().padding(top=16.dp)) { Text("ابدأ رحلتنا ♥") }
    }
}
@Composable private fun Field(value:String, change:(String)->Unit, label:String) {
    OutlinedTextField(value,change,label={Text(label)},singleLine=true,modifier=Modifier.fillMaxWidth().padding(vertical=6.dp), colors=OutlinedTextFieldDefaults.colors(focusedTextColor=Color.White,unfocusedTextColor=Color.White,focusedLabelColor=pink,unfocusedLabelColor=Color.LightGray))
}
@Composable private fun Home(a:String,b:String,open:(String)->Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF201832),bg,Color(0xFF17152D))))) {
        StarField()
        Column(Modifier.fillMaxSize().verticalScrollCompat().padding(horizontal=22.dp, vertical=30.dp), horizontalAlignment=Alignment.CenterHorizontally) {
            Text("عالمنا الخاص",fontSize=30.sp,fontWeight=FontWeight.Bold,color=Color.White)
            Text("$a  ♥  $b",fontSize=17.sp,color=pink,modifier=Modifier.padding(8.dp))
            Text("مساحة صغيرة تجمع حكايتكما",color=Color.LightGray,fontSize=13.sp)
            Spacer(Modifier.height(18.dp))
            val entries=listOf("stars" to "🌌 سماؤنا المشتركة","garden" to "🌷 حديقتنا","memories" to "💌 ذكرياتنا","questions" to "❓ سؤال اليوم","counter" to "⏳ عدّاد علاقتنا","capsule" to "🕰️ كبسولة المستقبل","pair" to "🔗 ربط الجهازين","settings" to "⚙️ إعداداتنا")
            entries.forEach { (id,label) -> MenuTile(label) { open(id) } }
            Text("كل ذكرى صغيرة تستحق مكانًا",color=Color.Gray,fontSize=12.sp,modifier=Modifier.padding(18.dp))
        }
    }
}
@Composable private fun Modifier.verticalScrollCompat(): Modifier = this.then(Modifier)
@Composable private fun MenuTile(label:String,onClick:()->Unit) {
    Surface(Modifier.fillMaxWidth().padding(vertical=5.dp).clickable(onClick=onClick),shape=RoundedCornerShape(18.dp),color=panel.copy(alpha=.92f)) {
        Text(label,color=Color.White,fontSize=17.sp,textAlign=TextAlign.Center,modifier=Modifier.padding(18.dp))
    }
}
@Composable private fun StarField() {
    val t= rememberInfiniteTransition(label="sky")
    val drift by t.animateFloat(0f,800f,infiniteRepeatable(tween(24000,easing=LinearEasing)),label="drift")
    Canvas(Modifier.fillMaxSize()) {
        repeat(115) { i ->
            val x=(i*83f+drift*(if(i%2==0) 1 else -.35f)).mod(size.width)
            val y=(i*137f).mod(size.height)
            drawCircle(Color.White.copy(alpha=.2f+(i%5)*.12f),radius=1f+(i%3),center=Offset(x,y))
        }
    }
}
@Composable private fun Stars(a:String,b:String,buzz:()->Unit) {
    var touch by remember { mutableStateOf(Offset.Zero) }
    Column(Modifier.fillMaxSize().background(bg).padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
        Text("سماء $a و $b",color=Color.White,fontSize=24.sp)
        Text("المس الشاشة لتترك أثرًا من الضوء",color=Color.LightGray)
        Canvas(Modifier.fillMaxWidth().height(360.dp).pointerInput(Unit) { detectDragGestures { change,_-> touch=change.position; buzz() } }) {
            val c=Offset(size.width/2,size.height/2)
            drawCircle(lilac.copy(alpha=.12f),130f,c)
            drawCircle(pink.copy(alpha=.7f),7f,c)
            drawCircle(Color.White.copy(alpha=.7f),5f,Offset(c.x-95,c.y-55))
            drawCircle(Color.White.copy(alpha=.7f),5f,Offset(c.x+105,c.y+65))
            drawLine(pink.copy(alpha=.65f),Offset(c.x-95,c.y-55),c,3f)
            drawLine(lilac.copy(alpha=.65f),c,Offset(c.x+105,c.y+65),3f)
            if(touch!=Offset.Zero) { drawCircle(pink.copy(alpha=.7f),16f,touch,style=androidx.compose.ui.graphics.drawscope.Stroke(3f)); drawCircle(Color.White,3f,touch) }
            repeat(7) { i -> drawCircle(Color.White.copy(alpha=.45f),2f,Offset((i*67f).mod(size.width),(i*91f).mod(size.height))) }
        }
        Text("✦ نجمتان، وسماء واحدة ✦",color=pink)
    }
}
@Composable private fun Garden(flowers:Int,plant:()->Unit) {
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF14382F),bg))).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
        Text("حديقتنا",fontSize=29.sp,color=Color.White)
        Text("كل ذكرى تسقي شيئًا جديدًا",color=Color.LightGray)
        Spacer(Modifier.height(35.dp))
        Text("🌳",fontSize=85.sp)
        Text("🌷".repeat(flowers.coerceAtMost(20)),fontSize=24.sp,textAlign=TextAlign.Center)
        Text("عدد الزهور: $flowers",color=pink,modifier=Modifier.padding(15.dp))
        Button(onClick=plant) { Text("ازرعوا زهرة جديدة") }
    }
}
@Composable private fun Memories(list:List<String>,add:(String)->Unit) {
    var value by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(bg).padding(20.dp)) {
        Text("ألبوم ذكرياتنا",fontSize=27.sp,color=Color.White)
        Field(value,{value=it},"اكتب ذكرى أو لحظة جميلة")
        Button(onClick={if(value.isNotBlank()){add(value.trim());value=""}},modifier=Modifier.fillMaxWidth()) { Text("احفظ الذكرى") }
        LazyColumn { items(list) { item -> Surface(Modifier.fillMaxWidth().padding(vertical=5.dp),color=panel,shape=RoundedCornerShape(14.dp)) { Text("♥  $item",color=Color.White,modifier=Modifier.padding(15.dp)) } } }
    }
}
private val prompts=listOf("ما أجمل ذكرى تتمنى أن نعيدها؟","ما حلم صغير تحب أن نحققه معًا؟","ما الشيء الذي يجعلك تشعر بالتقدير؟","أي مكان تتمنى زيارته يومًا؟","ما عادة لطيفة تحب أن نصنعها؟","ما أكثر شيء تعلمته عن نفسك مؤخرًا؟","كيف يمكننا دعم بعضنا بطريقة أفضل؟")
@Composable private fun Questions() {
    var index by remember { mutableIntStateOf(LocalDate.now().dayOfYear % prompts.size) }
    var answer by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(bg).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
        Text("سؤال اليوم",fontSize=28.sp,color=Color.White)
        Text(prompts[index],fontSize=22.sp,color=pink,textAlign=TextAlign.Center,modifier=Modifier.padding(28.dp))
        Field(answer,{answer=it},"اكتب إجابتك")
        Text("الإجابة تبقى على هذا الجهاز في هذه النسخة.",fontSize=12.sp,color=Color.Gray)
        Button(onClick={index=(index+1)%prompts.size;answer=""}) { Text("سؤال آخر") }
    }
}
@Composable private fun Counter(date:String) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while(true){now=System.currentTimeMillis();delay(1000)} }
    val days=runCatching { ChronoUnit.DAYS.between(LocalDate.parse(date),LocalDate.now()).coerceAtLeast(0) }.getOrDefault(0)
    Column(Modifier.fillMaxSize().background(bg).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
        Text("رحلتكما معًا",color=Color.White,fontSize=28.sp)
        Text("$days",fontSize=62.sp,color=pink,fontWeight=FontWeight.Bold)
        Text("يومًا من الذكريات",color=Color.LightGray)
        Text("يتجدد العداد كل ثانية • ${now/1000%60} ثانية",color=lilac,modifier=Modifier.padding(15.dp))
    }
}
@Composable private fun Capsule(value:String,save:(String)->Unit) {
    var text by remember(value) { mutableStateOf(value) }
    Column(Modifier.fillMaxSize().background(bg).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
        Text("كبسولة المستقبل",fontSize=27.sp,color=Color.White)
        Text("اكتب رسالة تريدان العودة إليها لاحقًا",color=Color.LightGray,modifier=Modifier.padding(12.dp))
        OutlinedTextField(text,{text=it},modifier=Modifier.fillMaxWidth().height(150.dp),label={Text("رسالتكما")})
        Button(onClick={save(text)},modifier=Modifier.fillMaxWidth().padding(top=12.dp)) { Text("احفظ الرسالة") }
        if(value.isNotBlank()) Text("رسالتكما محفوظة على هذا الجهاز 💌",color=pink,modifier=Modifier.padding(12.dp))
    }
}
@Composable private fun Pairing(code:String,save:(String)->Unit) {
    val generated=remember { (100000..999999).random().toString() }
    var entered by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(bg).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
        Text("ربط الجهازين",fontSize=28.sp,color=Color.White)
        Text("رمز دعوة تجريبي",color=Color.LightGray)
        Text(code.ifBlank { generated },fontSize=40.sp,color=pink,fontWeight=FontWeight.Bold,modifier=Modifier.padding(18.dp))
        Button(onClick={save(generated)}) { Text("اعتماد رمز الدعوة") }
        Divider(Modifier.padding(vertical=24.dp),color=Color.DarkGray)
        Field(entered,{entered=it},"أدخل رمز الطرف الآخر")
        Text("ملاحظة: إنشاء الرمز محلي فقط حاليًا. الربط والمزامنة بين جهازين يتطلبان إعداد خدمة سحابية.",fontSize=12.sp,color=Color.Gray,textAlign=TextAlign.Center)
    }
}
@Composable private fun Settings(a:String,b:String,d:String,h:Boolean,onA:(String)->Unit,onB:(String)->Unit,onD:(String)->Unit,onH:(Boolean)->Unit,save:()->Unit) {
    Column(Modifier.fillMaxSize().background(bg).padding(22.dp)) {
        Text("إعدادات عالمنا",fontSize=27.sp,color=Color.White)
        Field(a,onA,"اسمك"); Field(b,onB,"اسم الطرف الآخر"); Field(d,onD,"تاريخ البداية YYYY-MM-DD")
        Row(verticalAlignment=Alignment.CenterVertically) { Text("الاهتزاز",color=Color.White,modifier=Modifier.weight(1f)); Switch(h,onH) }
        Button(onClick=save,modifier=Modifier.fillMaxWidth()) { Text("حفظ التغييرات") }
    }
}
